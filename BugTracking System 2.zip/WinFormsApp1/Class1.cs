﻿using System.Text;
using System.Threading.Tasks;
namespace WinFormsApp1
{
    internal class Class1
    {
        string p;
        string u;
        string pass = "1234";
        string name = "Laiba";
        public bool validatep(string p)
        {
            if (p.Length < 4 || p == null)
            {
                MessageBox.Show("Password not validated.");
                return false;
            }
            else
            {
                return true;
            }
        }
        public bool Login(string u, string p)
        {
            if (validatep(p))
            {
                if (u == name && p == pass)
                {
                    return true;
                }
                else
                {
                    MessageBox.Show("Invalid username or password.");
                    return false;
                }
            }
            else
            {
                MessageBox.Show("Invalid password.");
                return false;
            }
        }
    }
}