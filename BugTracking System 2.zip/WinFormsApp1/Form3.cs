﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form3 : Form
    {
        // Connection string to your SQL Server database
        private string connectionString = "Data Source=Hamza;Initial Catalog=BugTracking;Integrated Security=True;";

        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Retrieve values from text boxes
            string bugTitle = textBoxBugTitle.Text.Trim();
            string description = textBoxDescription.Text.Trim();
            string stepsToReproduce = textBoxStepsToReproduce.Text.Trim();
            string expectedBehavior = textBoxExpectedBehavior.Text.Trim();
            string actualBehavior = textBoxActualBehavior.Text.Trim();

            // SQL INSERT command
            string query = "INSERT INTO BugReports (BugTitle, Description, StepsToReproduce, ExpectedBehavior, ActualBehavior) " +
                           "VALUES (@BugTitle, @Description, @StepsToReproduce, @ExpectedBehavior, @ActualBehavior)";

            // Create and open database connection
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    // Create command and set parameters
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@BugTitle", bugTitle);
                        command.Parameters.AddWithValue("@Description", description);
                        command.Parameters.AddWithValue("@StepsToReproduce", stepsToReproduce);
                        command.Parameters.AddWithValue("@ExpectedBehavior", expectedBehavior);
                        command.Parameters.AddWithValue("@ActualBehavior", actualBehavior);

                        // Execute the command
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Bug report added successfully!");
                        }
                        else
                        {
                            MessageBox.Show("Failed to add bug report.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }
    }
}
