﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form2 : Form
    {
        private string connectionString = "Data Source=Hamza;Initial Catalog=BugTracking;Integrated Security=True;";

        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Retrieve registration information from text boxes
            string username = textBoxUsername.Text.Trim();
            string email = textBoxEmail.Text.Trim();
            string number = textBoxNumber.Text.Trim();
            string password = textBoxPassword.Text.Trim();

            // Create SQL INSERT command
            string query = "INSERT INTO Registration (Username, Email, Number, Password) " +
                           "VALUES (@Username, @Email, @Number, @Password)";

            // Create and open database connection
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    // Create command and set parameters
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Username", username);
                        command.Parameters.AddWithValue("@Email", email);
                        command.Parameters.AddWithValue("@Number", number);
                        command.Parameters.AddWithValue("@Password", password);

                        // Execute the command
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Registration successful!");
                        }
                        else
                        {
                            MessageBox.Show("Registration failed.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }
    }
}
