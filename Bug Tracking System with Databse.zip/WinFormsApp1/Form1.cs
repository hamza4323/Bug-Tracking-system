private void button1_Click(object sender, EventArgs e)
{
    string username = textBox1.Text.Trim();
    string password = textBox2.Text.Trim();
    Class1 connect = new Class1();
    try
    {
        if (connect.Login(username, password))
        {
            // If login successful, hide current form and show Form3
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
        }
        else
        {
            MessageBox.Show("Invalid username or password");
        }
    }
    catch (Exception ex)
    {
        // Log the exception or handle it appropriately
        MessageBox.Show("An error occurred: " + ex.Message);
    }
}
